# app/models/__init__.py
from .models import Student, Admin, MenuItem, Order, Review, Staff, Task